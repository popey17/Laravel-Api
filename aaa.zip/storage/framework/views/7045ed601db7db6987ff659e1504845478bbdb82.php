<?php $__env->startSection('mainContent'); ?>
<div class="">
  hello this is admin page
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.rightPanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/popey/Personal FIles/Github Repos/Laravel-Api/resources/views/components/admin.blade.php ENDPATH**/ ?>