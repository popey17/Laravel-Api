<div class="detail">
    <div>
        <img src="<?php echo e($deatilItem->image); ?>" alt="">
    </div>
    <div>
        <h1><?php echo e($deatilItem['name']); ?></h1>
    </div>
    <div>
        <p>item Code: <?php echo e($deatilItem->item_code); ?></p>
        <p>Price: <?php echo e($deatilItem->price); ?></p>
        <p>Category: <?php echo e($deatilItem->category->name); ?></p>
    </div>
    <div>
        <p>Description</p>
        <p><?php echo e($deatilItem->description); ?></p>
    </div>
</div><?php /**PATH /home/popey/Personal FIles/Github Repos/Laravel-Api/resources/views/components/productDetail.blade.php ENDPATH**/ ?>