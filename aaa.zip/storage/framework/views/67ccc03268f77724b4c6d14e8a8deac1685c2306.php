<?php $__env->startSection('mainContent'); ?>
<div class="mainContent">
    <div class="header">
        <h1>categories</h1>
        <div class="right">
            <div class="form-group">
                <input type="text" name="search" id="search" class="form-control" placeholder="Search Item" />
            </div>
            <a href="<?php echo e(route('addProduct')); ?>">
                <span class="title">Add Category</span>
                <span class="icon"><i class="fa-solid fa-plus"></i></span>
            </a>
        </div>
    </div>
    <div>
    <div class="d-flex cards container">
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="card me-3" style="width: 18rem;">
        <div class="card-body">
          <h5 class="card-title"> <?php echo e($category->name); ?></h5>
          <p class="card-text">Some Descriptions</p>
          <a href="#" class="btn btn-primary">Show Products</a>
          <a href="#" class="btn btn-primary">delete</a>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
      
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('components.rightPanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/popey/Personal FIles/Github Repos/Laravel-Api/resources/views/components/categories.blade.php ENDPATH**/ ?>