<div class="addProductForm" id="editForm" >
    <form action="/products/edit/<?php echo e($product['id']); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="formItems row">
            <label class="col-12 col-sm-3" for="itemCode">Item Code</label>
            <input class="col-12 col-sm-9" type="text" name="itemCode" value="<?php echo e($product['item_code']); ?>">
        </div>
        <div class="formItems row">
            <label class="col-12 col-sm-3" for="name">Item Name</label>
            <input class="col-12 col-sm-9" type="text" name="name" value="<?php echo e($product['name']); ?>" required>
        </div>
        <div class="formItems row ">
            <label class="col-12 col-sm-3" for="description">Product Description</label>
            <textarea class="col-12 col-sm-9" type="text" name="description" required><?php echo e($product['description']); ?></textarea>
        </div>
        <div class="formItems row">
            <label class="col-12 col-sm-3" for="price">Price</label>
            <input class="col-12 col-sm-9" type="number" name="price" value="<?php echo e($product['price']); ?>" required>
        </div>
        <div class="formItems row">
            <label class="col-12 col-sm-3" for="category">Category</label>
            <select class="col-12 col-sm-9" name="category" id="category" required>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category["id"]); ?>"
                        <?php if($category->id === $product['category_id']): ?>
                            selected
                        <?php endif; ?>>
                        <?php echo e($category["name"]); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="formItems row">
            <label class="col-12 col-sm-3" for="image">Add Image</label>
            <input class="col-12 col-sm-9" type="file" value="<?php echo e($product->image); ?>" name="image">
        </div>
        <div>
            <input type="submit" value="Edit Product"
            class="btn btn-primary addProductBtn">
        </div>
    </form>
    <button class="btn btn-primary addProductBtn cancelBtn">Cancel</button>
</div><?php /**PATH /home/popey/Personal FIles/Github Repos/Laravel-Api/resources/views/components/productEdit.blade.php ENDPATH**/ ?>