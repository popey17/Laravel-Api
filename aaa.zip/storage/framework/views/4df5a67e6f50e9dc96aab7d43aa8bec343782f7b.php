<?php $__env->startSection('content'); ?>
<section class="main-container row">
  <div class="left-nav-container col-2 col-md-3 col-xxl-2">
      <ul>
        <li class="side-nav-items">
          <b></b>
          <b></b>
          <a href="<?php echo e(route('admin')); ?>">
            <span class="icon"><i class="fa-solid fa-gear"></i></span>
            <span class="title">Admin Panel</span>
          </a>
        </li>
        <li class="side-nav-items">
          <b></b>
          <b></b>
          <a href="<?php echo e(route('products')); ?>">
            <span class="icon"><i class="fa-solid fa-boxes-stacked"></i></span>
            <span class="title">Products</span>
          </a>
        </li>
        <li class="side-nav-items">
          <b></b>
          <b></b>
          <a href="<?php echo e(route('categories')); ?>">
            <span class="icon"><i class="fa-solid fa-clipboard"></i></span>
            <span class="title">Categories</span>
          </a>
        </li>
      </ul>
  </div>
  <div class="col-10 col-md-9 col-xxl-10 main-content">
    <?php echo $__env->yieldContent('mainContent'); ?>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/popey/Personal FIles/Github Repos/Laravel-Api/resources/views/components/rightPanel.blade.php ENDPATH**/ ?>