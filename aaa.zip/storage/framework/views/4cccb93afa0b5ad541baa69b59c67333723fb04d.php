<?php $__env->startSection('mainContent'); ?>
<div class="mainContent">
    <div class="header">
        <h1>Add products</h1>
        <a href="<?php echo e(route('products')); ?>">
            <span class="icon"><i class="fa-solid fa-arrow-left"></i></span>
            <span class="title">Back</span>
        </a>
    </div>
    <div class="addProductForm">
        <form method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="formItems row">
                <label class="col-12 col-sm-3" for="itemCode">Item Code</label>
                <input class="col-12 col-sm-9" type="text" name="itemCode" required>
            </div>
            <div class="formItems row">
                <label class="col-12 col-sm-3" for="name">Item Name</label>
                <input class="col-12 col-sm-9" type="text" name="name" required>
            </div>
            <div class="formItems row ">
                <label class="col-12 col-sm-3" for="description">Product Description</label>
                <textarea class="col-12 col-sm-9" type="text" name="description" required></textarea>
            </div>
            <div class="formItems row">
                <label class="col-12 col-sm-3" for="price">Price</label>
                <input class="col-12 col-sm-9" type="number" name="price" required>
            </div>
            <div class="formItems row">
                <label class="col-12 col-sm-3" for="category">Category</label>
                <select class="col-12 col-sm-9" name="category" id="category" required>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category["id"]); ?>">
                            <?php echo e($category["name"]); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="formItems row">
                <label class="col-12 col-sm-3" for="image">Add Image</label>
                <input class="col-12 col-sm-9" type="file" name="image">
            </div>
            <input type="submit" value="Add Product"
            class="btn btn-primary addProductBtn">
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.rightPanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/popey/Personal FIles/Github Repos/Laravel-Api/resources/views/components/addProduct.blade.php ENDPATH**/ ?>