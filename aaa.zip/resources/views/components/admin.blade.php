@extends('components.rightPanel')

@section('mainContent')
<div class="">
  hello this is admin page
</div>
@endsection